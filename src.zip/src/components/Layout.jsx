import { Link } from "react-router-dom";
import { getAuth, signOut } from "firebase/auth";

function Layout({ children }) {
  const auth = getAuth();

  const handleLogout = async () => {
    await signOut(auth);
  };

  return (
    <div className="flex h-screen bg-gray-100">

      {/* Sidebar */}
      <div className="w-64 bg-white border-r p-5 flex flex-col">
        <h1 className="text-xl font-bold mb-6">SmartKitchen</h1>

        <nav className="flex flex-col gap-3">
          <Link to="/" className="p-2 hover:bg-gray-100 rounded">Dashboard</Link>
          <Link to="/cook" className="p-2 hover:bg-gray-100 rounded">Cook</Link>
          <Link to="/ingredients" className="p-2 hover:bg-gray-100 rounded">Ingredients</Link>
          <Link to="/logs" className="p-2 hover:bg-gray-100 rounded">Logs</Link>
          <Link to="/analytics" className="p-2 hover:bg-gray-100 rounded">Analytics</Link>
          <Link to="/settings" className="p-2 hover:bg-gray-100 rounded">Settings</Link>
        </nav>

        <button
          onClick={handleLogout}
          className="mt-auto bg-red-500 text-white p-2 rounded"
        >
          Logout
        </button>
      </div>

      {/* Main */}
      <div className="flex-1 flex flex-col">

        {/* Header */}
        <div className="bg-white p-4 border-b flex justify-between">
          <h1 className="font-semibold">Dashboard</h1>
          <span className="text-green-600">● Connected</span>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto">
          {children}
        </div>

      </div>
    </div>
  );
}

export default Layout;