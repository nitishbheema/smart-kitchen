import { db } from "../firebase/firebaseConfig";
import { ref, onValue } from "firebase/database";

export const listenWeight = (callback) => {
  const weightRef = ref(db, "liveData/weight");

  onValue(weightRef, (snapshot) => {
    const data = snapshot.val();
    callback(data);
  });
};