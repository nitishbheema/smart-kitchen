import { db } from "../firebase/firebaseConfig";
import { ref, onValue } from "firebase/database";

export const listenRFID = (callback) => {
  const rfidRef = ref(db, "liveData/currentRFID");

  onValue(rfidRef, (snapshot) => {
    const data = snapshot.val();
    callback(data);
  });
};