import { db } from "../firebase/firebaseConfig";
import { ref, push } from "firebase/database";
import { getAuth } from "firebase/auth";

export const addLog = (data) => {
  const auth = getAuth();
  const user = auth.currentUser;

  const logRef = ref(db, "logs");

  console.log("LOGGING:", data); // debug

  push(logRef, {
    ...data,
    user: user?.email || "unknown",
    timestamp: Date.now(),
  });
};