import { useEffect, useState } from "react";
import { listenWeight } from "../services/weightService";
import { listenRFID } from "../services/rfidService";
import { listenRecipes } from "../services/recipeService";
import { listenFlow } from "../services/flowService";
import { checkStatus } from "../utils/toleranceCheck";
import { addLog } from "../services/logService";

function Dashboard() {
  const [weight, setWeight] = useState(0);
  const [item, setItem] = useState("None");
  const [recipes, setRecipes] = useState({});
  const [flow, setFlow] = useState({});
  const [step, setStep] = useState(0);
  const [alerts, setAlerts] = useState([]);
  const [logged, setLogged] = useState(false);

  // 🔹 Firebase listeners
  useEffect(() => {
    listenWeight(setWeight);
    listenRFID(setItem);
    listenRecipes(setRecipes);

    try {
      listenFlow("biryani", setFlow);
    } catch (e) {
      console.log("Flow error:", e);
    }
  }, []);

  // 🔹 Safe values
  const target = recipes?.[item?.toLowerCase()] || 0;
  const expectedItem = flow?.[step] || "";

  const isCorrectItem =
    item?.toLowerCase() === expectedItem;

  const status = checkStatus(weight, target);
  const isError = !isCorrectItem || status !== "OK";

  // 🔥 AUTO LOGGING (CORE)
  useEffect(() => {
    if (!isError && expectedItem && target > 0 && !logged) {
      addLog({
        item,
        weight,
        target,
        status,
        step,
      });

      setLogged(true);
      setStep((prev) => prev + 1);
    }

    if (isError) {
      setLogged(false);
    }
  }, [isError]);

  // 🔹 Alerts
  useEffect(() => {
    if (target === 0) return;

    if (weight > target) {
      setAlerts(["Over usage detected"]);
    } else if (weight < target - 20) {
      setAlerts(["Low usage"]);
    } else {
      setAlerts([]);
    }
  }, [weight, target]);

  // 🔹 Buzzer
  useEffect(() => {
    if (isError) console.log("BUZZER ON");
    else console.log("BUZZER OFF");
  }, [isError]);

  const bgColor = isError ? "#ffcccc" : "#ccffcc";

  return (
    <div style={{ padding: "20px", backgroundColor: bgColor }}>
      <h1>Dashboard</h1>

      <h2>Ingredient: {item}</h2>

      <h2>Expected: {expectedItem || "N/A"}</h2>

      <h2>
        Match: {isCorrectItem ? "YES ✅" : "NO ❌"}
      </h2>

      <h2>Target: {target} g</h2>

      <h2>Live Weight: {weight} g</h2>

      <h2>Status: {status}</h2>

      <h2>Step: {step}</h2>

      {alerts.map((a, i) => (
        <p key={i} style={{ color: "orange" }}>{a}</p>
      ))}

      {isError && (
        <h1 style={{ color: "red" }}>
          ⚠️ ERROR: FIX INPUT
        </h1>
      )}
    </div>
  );
}

export default Dashboard;