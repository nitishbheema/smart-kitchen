import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./services/useAuth";

import Dashboard from "./pages/Dashboard";
import CookingMode from "./pages/CookingMode";
import Ingredients from "./pages/Ingredients";
import Logs from "./pages/Logs";
import Analytics from "./pages/Analytics";
import Settings from "./pages/Settings";
import Auth from "./pages/Auth";
import Layout from "./components/Layout";

function App() {
  const user = useAuth();

  if (user === undefined) {
    return <h1>Loading...</h1>;
  }

  return (
    <BrowserRouter>
      <Routes>

        {/* Auth */}
        <Route
          path="/auth"
          element={!user ? <Auth /> : <Navigate to="/" />}
        />

        {/* Protected Routes */}
        <Route
          path="/"
          element={user ? <Layout><Dashboard /></Layout> : <Navigate to="/auth" />}
        />

        <Route
          path="/cook"
          element={user ? <Layout><CookingMode /></Layout> : <Navigate to="/auth" />}
        />

        <Route
          path="/ingredients"
          element={user ? <Layout><Ingredients /></Layout> : <Navigate to="/auth" />}
        />

        <Route
          path="/logs"
          element={user ? <Layout><Logs /></Layout> : <Navigate to="/auth" />}
        />

        <Route
          path="/analytics"
          element={user ? <Layout><Analytics /></Layout> : <Navigate to="/auth" />}
        />

        <Route
          path="/settings"
          element={user ? <Layout><Settings /></Layout> : <Navigate to="/auth" />}
        />

        {/* Fallback */}
        <Route path="*" element={<Navigate to={user ? "/" : "/auth"} />} />

      </Routes>
    </BrowserRouter>
  );
}

export default App;